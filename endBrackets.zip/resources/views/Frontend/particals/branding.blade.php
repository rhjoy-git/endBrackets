<section class="pt-16 bg-gray-50 container flex justify-center items-center text-center px-4 sm:px-6 lg:px-12 overflow-hidden">
    <div class=" max-w-4xl text-center">
        <p class="text-2xl md:text-3xl font-medium mb-8">
            Unlock your brand's potential with End Brackets' design and development expertise, locally and globally.
        </p>
    </div>
</section>